# Figures

Recommended repository figures:

- `pipeline.png` — CoCoGen method overview
- `qualitative_comparison.png` — clean/adversarial/difference-map comparison
- `transferability.png` — transferability results

Only add figures that are cleared for redistribution and consistent with the final camera-ready paper.
