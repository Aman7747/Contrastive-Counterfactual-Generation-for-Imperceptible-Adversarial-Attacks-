# Checkpoints

This directory is reserved for locally downloaded or user-provided checkpoints.

Do not commit pretrained ImageNet weights or other non-redistributable model files unless their license explicitly permits redistribution.

For reproducibility, record the exact architecture, checkpoint identifier, library version, and source used for each model.
