# Dataset Preparation

The supplied ImageNet-Mini implementation expects:

```text
imagenet-mini/
└── val/
    ├── <class>/
    │   ├── image1.JPEG
    │   └── ...
    └── ...
```

The default Kaggle path recognized by the code is:

```text
/kaggle/input/imagenetmini-1000/imagenet-mini/val
```

Do not commit ImageNet or other restricted datasets to this repository.

For CIFAR-100 reproduction, use the official dataset distribution and follow its terms. The currently supplied experiment drivers are primarily organized around ImageNet-Mini.
