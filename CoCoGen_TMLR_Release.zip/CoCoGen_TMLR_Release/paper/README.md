# Paper

Place the final camera-ready PDF here as:

```text
cocogen_tmlr.pdf
```

The repository release accompanying the paper should contain the exact camera-ready version used for publication.

OpenReview:

https://openreview.net/forum?id=dnme31GvOd
